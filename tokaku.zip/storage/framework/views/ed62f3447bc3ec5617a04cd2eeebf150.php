<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — <?php echo e($currentTenant->name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">


<nav class="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
    <div class="flex items-center gap-2">
        <div class="w-8 h-8 bg-emerald-700 rounded-lg flex items-center justify-center">
            <span class="text-white font-bold text-sm">T</span>
        </div>
        <span class="font-semibold text-gray-800"><?php echo e($currentTenant->name); ?></span>
    </div>
    <div class="flex items-center gap-4">
        <span class="text-sm text-gray-500"><?php echo e(auth()->user()->name); ?></span>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="text-sm text-gray-500 hover:text-red-600 transition-colors">Keluar</button>
        </form>
    </div>
</nav>

<div class="max-w-6xl mx-auto px-6 py-8">

    
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-lg px-4 py-3 mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <p class="text-xs text-gray-400 mb-1">Omzet hari ini</p>
            <p class="text-xl font-semibold text-gray-800">Rp <?php echo e(number_format($todayRevenue, 0, ',', '.')); ?></p>
        </div>
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <p class="text-xs text-gray-400 mb-1">Transaksi hari ini</p>
            <p class="text-xl font-semibold text-gray-800"><?php echo e($todayCount); ?></p>
        </div>
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <p class="text-xs text-gray-400 mb-1">Omzet bulan ini</p>
            <p class="text-xl font-semibold text-gray-800">Rp <?php echo e(number_format($monthRevenue, 0, ',', '.')); ?></p>
        </div>
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <p class="text-xs text-gray-400 mb-1">Transaksi bulan ini</p>
            <p class="text-xl font-semibold text-gray-800"><?php echo e($monthCount); ?></p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        
        <div class="bg-white rounded-xl border border-gray-200 p-6">
            <h2 class="font-medium text-gray-800 mb-4">Stok menipis</h2>
            <?php if($lowStockProducts->isEmpty()): ?>
                <p class="text-sm text-gray-400">Semua stok aman.</p>
            <?php else: ?>
                <div class="space-y-3">
                    <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-gray-700"><?php echo e($product->name); ?></p>
                                <p class="text-xs text-gray-400"><?php echo e($product->category?->name ?? '-'); ?></p>
                            </div>
                            <span class="text-sm font-semibold <?php echo e($product->stock <= 0 ? 'text-red-600' : 'text-amber-600'); ?>">
                                <?php echo e($product->stock); ?> sisa
                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="bg-white rounded-xl border border-gray-200 p-6">
            <h2 class="font-medium text-gray-800 mb-4">Transaksi terbaru</h2>
            <?php if($recentTransactions->isEmpty()): ?>
                <p class="text-sm text-gray-400">Belum ada transaksi.</p>
            <?php else: ?>
                <div class="space-y-3">
                    <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-gray-700"><?php echo e($trx->invoice_no); ?></p>
                                <p class="text-xs text-gray-400"><?php echo e($trx->user->name); ?> &middot; <?php echo e($trx->created_at->diffForHumans()); ?></p>
                            </div>
                            <span class="text-sm font-semibold text-gray-800">
                                Rp <?php echo e(number_format($trx->total, 0, ',', '.')); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

    </div>

    
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        <a href="<?php echo e(route('tenant.kasir.index')); ?>" class="bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl p-5 text-center transition-colors">
            <p class="font-medium">Kasir</p>
            <p class="text-xs text-emerald-200 mt-1">Buat transaksi</p>
        </a>
        <a href="<?php echo e(route('tenant.products.index')); ?>" class="bg-white hover:bg-gray-50 border border-gray-200 rounded-xl p-5 text-center transition-colors">
            <p class="font-medium text-gray-700">Produk</p>
            <p class="text-xs text-gray-400 mt-1">Kelola stok</p>
        </a>
        <a href="<?php echo e(route('tenant.laporan.index')); ?>" class="bg-white hover:bg-gray-50 border border-gray-200 rounded-xl p-5 text-center transition-colors">
            <p class="font-medium text-gray-700">Laporan</p>
            <p class="text-xs text-gray-400 mt-1">Omzet & transaksi</p>
        </a>
        <?php if(auth()->user()->isAdmin()): ?>
        <a href="<?php echo e(route('tenant.profil')); ?>" class="bg-white hover:bg-gray-50 border border-gray-200 rounded-xl p-5 text-center transition-colors">
            <p class="font-medium text-gray-700">Pengaturan</p>
            <p class="text-xs text-gray-400 mt-1">Profil toko</p>
        </a>
        <?php endif; ?>
    </div>

</div>
</body>
</html>
<?php /**PATH D:\Project\1017website 2026\tokaku\resources\views/tenant/dashboard/index.blade.php ENDPATH**/ ?>