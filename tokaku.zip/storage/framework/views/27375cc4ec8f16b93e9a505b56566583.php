<?php $__env->startSection('title','Kelola Tenant'); ?>
<?php $__env->startSection('page-title','Kelola Tenant'); ?>
<?php $__env->startSection('page-subtitle','Semua toko yang terdaftar di Tokaku'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
    <div>
        <div style="background:#fff;border-radius:14px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);padding:22px;">
            <p style="font-size:14px;font-weight:600;color:#0f172a;margin-bottom:16px;">Tambah Tenant Baru</p>
            <form method="POST" action="<?php echo e(route('superadmin.tenants.store')); ?>" style="display:flex;flex-direction:column;gap:13px;">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                <div style="background:#fff1f2;border:1px solid #fecdd3;color:#be123c;font-size:12.5px;border-radius:10px;padding:10px 14px;"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
                <div>
                    <label style="display:block;font-size:12.5px;font-weight:500;color:#374151;margin-bottom:5px;">Nama Toko *</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" required class="form-input" placeholder="Warung Budi">
                </div>
                <div>
                    <label style="display:block;font-size:12.5px;font-weight:500;color:#374151;margin-bottom:5px;">Subdomain *</label>
                    <div style="display:flex;border:1.5px solid #e2e8f0;border-radius:10px;overflow:hidden;background:#fafafa;">
                        <input type="text" name="subdomain" value="<?php echo e(old('subdomain')); ?>" required
                            style="flex:1;border:none;padding:10px 12px;font-size:13.5px;font-family:Inter,sans-serif;outline:none;background:transparent;color:#0f172a;"
                            placeholder="warungbudi">
                        <span style="padding:10px 12px;font-size:12px;color:#94a3b8;background:#f8fafc;border-left:1.5px solid #e2e8f0;white-space:nowrap;">.tokaku.id</span>
                    </div>
                </div>
                <div>
                    <label style="display:block;font-size:12.5px;font-weight:500;color:#374151;margin-bottom:5px;">Nomor HP</label>
                    <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="form-input" placeholder="08xxxxxxxxxx">
                </div>
                <div style="padding-top:8px;border-top:1px solid #f1f5f9;">
                    <p style="font-size:12px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:0.4px;margin-bottom:10px;">Akun Owner</p>
                    <div style="display:flex;flex-direction:column;gap:10px;">
                        <div>
                            <label style="display:block;font-size:12.5px;font-weight:500;color:#374151;margin-bottom:5px;">Email *</label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required class="form-input" placeholder="owner@email.com">
                        </div>
                        <div>
                            <label style="display:block;font-size:12.5px;font-weight:500;color:#374151;margin-bottom:5px;">Password *</label>
                            <input type="password" name="password" required class="form-input" placeholder="min. 8 karakter">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn-primary" style="justify-content:center;margin-top:4px;">Buat Tenant</button>
            </form>
        </div>
    </div>

    <div class="lg:col-span-2">
        <div style="background:#fff;border-radius:14px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);overflow:hidden;">
            <div style="padding:16px 20px;border-bottom:1px solid #f8fafc;">
                <p style="font-size:14px;font-weight:600;color:#0f172a;">Semua Tenant (<?php echo e($tenants->total()); ?>)</p>
            </div>
            <div>
                <?php $__empty_1 = true; $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="padding:16px 20px;border-bottom:1px solid #f8fafc;">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                        <div style="display:flex;align-items:center;gap:12px;">
                            <div style="width:40px;height:40px;background:#f0fdf6;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                <span style="color:#0F6E56;font-size:14px;font-weight:700;"><?php echo e(strtoupper(substr($t->name,0,2))); ?></span>
                            </div>
                            <div>
                                <p style="font-size:14px;font-weight:600;color:#0f172a;"><?php echo e($t->name); ?></p>
                                <p style="font-size:12px;font-family:monospace;color:#94a3b8;margin-top:1px;"><?php echo e($t->subdomain); ?>.tokaku.id</p>
                                <p style="font-size:11.5px;color:#94a3b8;margin-top:2px;"><?php echo e($t->users_count); ?> user &middot; <?php echo e($t->created_at->format('d M Y')); ?></p>
                            </div>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                            <?php if($t->status==='active'): ?><span style="font-size:12px;font-weight:500;background:#f0fdf4;color:#15803d;padding:4px 10px;border-radius:99px;">Aktif</span>
                            <?php elseif($t->status==='trial'): ?><span style="font-size:12px;font-weight:500;background:#fffbeb;color:#b45309;padding:4px 10px;border-radius:99px;">Trial <?php echo e($t->trial_ends_at?'· '.$t->trial_ends_at->diffForHumans():''); ?></span>
                            <?php else: ?><span style="font-size:12px;font-weight:500;background:#fff1f2;color:#be123c;padding:4px 10px;border-radius:99px;">Suspended</span><?php endif; ?>
                            <form method="POST" action="<?php echo e(route('superadmin.tenants.suspend',$t)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <button type="submit" onclick="return confirm('<?php echo e($t->status==='suspended'?'Aktifkan':'Tangguhkan'); ?> tenant ini?')"
                                    style="font-size:12.5px;font-weight:500;padding:6px 12px;border-radius:8px;border:1.5px solid;cursor:pointer;font-family:Inter,sans-serif;background:#fff;transition:all 0.15s;<?php echo e($t->status==='suspended'?'border-color:#bbf7d2;color:#15803d;':'border-color:#fecdd3;color:#be123c;'); ?>">
                                    <?php echo e($t->status==='suspended'?'Aktifkan':'Tangguhkan'); ?>

                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div style="padding:60px 20px;text-align:center;font-size:14px;color:#94a3b8;">Belum ada tenant terdaftar.</div>
                <?php endif; ?>
            </div>
            <?php if($tenants->hasPages()): ?>
            <div style="padding:14px 20px;border-top:1px solid #f8fafc;"><?php echo e($tenants->links()); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\1017website 2026\tokaku\resources\views/superadmin/tenants/index.blade.php ENDPATH**/ ?>