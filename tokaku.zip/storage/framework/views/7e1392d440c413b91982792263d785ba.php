<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('page-title','Dashboard'); ?>
<?php $__env->startSection('page-subtitle','Ringkasan seluruh tenant Tokaku'); ?>
<?php $__env->startSection('header-actions'); ?>
<a href="<?php echo e(route('superadmin.tenants')); ?>" class="btn-primary">
    <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
    Tambah Tenant
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:20px;">
    <?php $__currentLoopData = [['Total Tenant',$totalTenants,'toko terdaftar','#0F6E56','#f0fdf6','M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4'],['Tenant Aktif',$activeTenants,'berlangganan aktif','#16a34a','#f0fdf4','M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z'],['Masa Trial',$trialTenants,'sedang trial','#d97706','#fffbeb','M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$lbl,$val,$sub,$clr,$bg,$icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="background:#fff;border-radius:14px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);padding:18px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <p style="font-size:12px;font-weight:500;color:#64748b;"><?php echo e($lbl); ?></p>
            <div style="width:30px;height:30px;background:<?php echo e($bg); ?>;border-radius:8px;display:flex;align-items:center;justify-content:center;">
                <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="<?php echo e($clr); ?>" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($icon); ?>"/></svg>
            </div>
        </div>
        <p style="font-size:24px;font-weight:700;color:#0f172a;letter-spacing:-0.5px;"><?php echo e($val); ?></p>
        <p style="font-size:11.5px;color:#94a3b8;margin-top:4px;"><?php echo e($sub); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div style="background:#fff;border-radius:14px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);overflow:hidden;">
    <div style="padding:16px 20px;border-bottom:1px solid #f8fafc;display:flex;align-items:center;justify-content:space-between;">
        <p style="font-size:14px;font-weight:600;color:#0f172a;">Tenant Terbaru</p>
        <a href="<?php echo e(route('superadmin.tenants')); ?>" style="font-size:12px;color:#0F6E56;font-weight:500;text-decoration:none;">Lihat semua</a>
    </div>
    <div class="overflow-x-auto">
        <table style="width:100%;border-collapse:collapse;min-width:400px;">
            <thead><tr style="background:#f8fafc;border-bottom:1px solid #f1f5f9;">
                <?php $__currentLoopData = ['Nama Toko','Subdomain','Status','Terdaftar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="text-align:left;font-size:11px;font-weight:600;color:#64748b;padding:10px 18px;text-transform:uppercase;letter-spacing:0.3px;"><?php echo e($h); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr></thead>
            <tbody>
            <?php $__currentLoopData = \App\Models\Tenant::latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom:1px solid #f8fafc;transition:background 0.1s;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='#fff'">
                <td style="padding:13px 18px;font-size:13.5px;font-weight:500;color:#0f172a;"><?php echo e($t->name); ?></td>
                <td style="padding:13px 18px;font-family:monospace;font-size:12.5px;color:#64748b;"><?php echo e($t->subdomain); ?></td>
                <td style="padding:13px 18px;">
                    <?php if($t->status==='active'): ?><span style="font-size:12px;font-weight:500;background:#f0fdf4;color:#15803d;padding:3px 10px;border-radius:99px;">Aktif</span>
                    <?php elseif($t->status==='trial'): ?><span style="font-size:12px;font-weight:500;background:#fffbeb;color:#b45309;padding:3px 10px;border-radius:99px;">Trial</span>
                    <?php else: ?><span style="font-size:12px;font-weight:500;background:#fff1f2;color:#be123c;padding:3px 10px;border-radius:99px;">Suspended</span><?php endif; ?>
                </td>
                <td style="padding:13px 18px;font-size:13px;color:#64748b;"><?php echo e($t->created_at->format('d M Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\1017website 2026\tokaku\resources\views/superadmin/dashboard.blade.php ENDPATH**/ ?>