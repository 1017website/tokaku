<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk — Tokaku</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50:  '#f0fdf6',
                            100: '#dcfce9',
                            200: '#bbf7d2',
                            500: '#22c55e',
                            600: '#16a34a',
                            700: '#0F6E56',
                            800: '#085041',
                            900: '#04342C',
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.4s ease-out',
                        'slide-up': 'slideUp 0.4s ease-out',
                    },
                    keyframes: {
                        fadeIn:  { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
                        slideUp: { '0%': { opacity: '0', transform: 'translateY(12px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
                    }
                }
            }
        }
    </script>
</head>
<body class="min-h-screen bg-gray-50 flex">

    
    <div class="hidden lg:flex lg:w-1/2 bg-primary-700 flex-col justify-between p-12 relative overflow-hidden">

        
        <div class="absolute -top-24 -right-24 w-72 h-72 bg-white/5 rounded-full"></div>
        <div class="absolute top-1/3 -left-16 w-48 h-48 bg-white/5 rounded-full"></div>
        <div class="absolute -bottom-16 right-16 w-56 h-56 bg-white/5 rounded-full"></div>

        
        <div class="relative z-10">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center">
                    <svg width="22" height="22" viewBox="0 0 18 18" fill="none">
                        <path d="M3 5h12M3 9h8M3 13h5" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="text-white text-xl font-bold">Tokaku</span>
            </div>
        </div>

        
        <div class="relative z-10">
            <h2 class="text-white text-3xl font-bold leading-snug mb-4">
                Toko kamu,<br>lebih mudah.
            </h2>
            <p class="text-primary-200 text-sm leading-relaxed max-w-xs">
                Kelola kasir, stok, dan laporan penjualan dalam satu platform yang simpel dan cepat.
            </p>

            
            <div class="mt-8 space-y-3">
                <?php $__currentLoopData = ['Kasir digital yang mudah dipakai', 'Laporan penjualan real-time', 'Kelola stok otomatis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center gap-3">
                    <div class="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                        <svg width="10" height="10" fill="none" viewBox="0 0 24 24" stroke="white" stroke-width="3">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                        </svg>
                    </div>
                    <span class="text-primary-100 text-sm"><?php echo e($feat); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="relative z-10">
            <p class="text-primary-300 text-xs">by <span class="text-white font-medium">1017studios.id</span></p>
        </div>
    </div>

    
    <div class="w-full lg:w-1/2 flex items-center justify-center p-6">
        <div class="w-full max-w-sm animate-slide-up">

            
            <div class="flex items-center gap-2.5 mb-8 lg:hidden">
                <div class="w-9 h-9 bg-primary-700 rounded-xl flex items-center justify-center">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                        <path d="M3 5h12M3 9h8M3 13h5" stroke="white" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="text-xl font-bold text-gray-800">Tokaku</span>
            </div>

            <div class="mb-8">
                <h1 class="text-2xl font-bold text-gray-900">Selamat datang</h1>
                <p class="text-gray-500 text-sm mt-1">Masuk untuk melanjutkan ke dashboard Anda</p>
            </div>

            
            <?php if($errors->any()): ?>
                <div class="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl px-4 py-3.5 mb-6">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="#dc2626" stroke-width="2" class="flex-shrink-0 mt-0.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <p class="text-sm text-red-700"><?php echo e($errors->first()); ?></p>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login.post')); ?>" class="space-y-5">
                <?php echo csrf_field(); ?>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="#9ca3af" stroke-width="1.8">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                        </div>
                        <input
                            type="email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            placeholder="email@toko.com"
                            autofocus
                            class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-2xl text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-700 focus:border-transparent transition-all placeholder-gray-300 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-300 bg-red-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        >
                    </div>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="#9ca3af" stroke-width="1.8">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                            </svg>
                        </div>
                        <input
                            type="password"
                            name="password"
                            id="passwordInput"
                            placeholder="••••••••"
                            class="w-full pl-11 pr-12 py-3 border border-gray-200 rounded-2xl text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-700 focus:border-transparent transition-all placeholder-gray-300"
                        >
                        
                        <button
                            type="button"
                            id="togglePassword"
                            onclick="togglePass()"
                            class="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 transition-colors"
                        >
                            <svg id="eyeIcon" width="17" height="17" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                            <svg id="eyeOffIcon" width="17" height="17" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8" class="hidden">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                            </svg>
                        </button>
                    </div>
                </div>

                
                <div class="flex items-center justify-between">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="remember"
                            class="w-4 h-4 rounded-md border-gray-300 text-primary-700 focus:ring-primary-700 cursor-pointer">
                        <span class="text-sm text-gray-600">Ingat saya</span>
                    </label>
                </div>

                
                <button
                    type="submit"
                    class="w-full bg-primary-700 hover:bg-primary-800 active:scale-[0.98] text-white font-semibold py-3 rounded-2xl text-sm transition-all shadow-lg shadow-primary-700/20 flex items-center justify-center gap-2"
                >
                    Masuk ke Dashboard
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                    </svg>
                </button>

            </form>

            <p class="text-center text-xs text-gray-400 mt-8">
                Tokaku &copy; <?php echo e(date('Y')); ?> &middot; by
                <a href="https://1017studios.id" class="text-gray-500 hover:text-primary-700 transition-colors font-medium">1017studios.id</a>
            </p>
        </div>
    </div>

</body>
<script>
function togglePass() {
    const input   = document.getElementById('passwordInput');
    const eyeOn   = document.getElementById('eyeIcon');
    const eyeOff  = document.getElementById('eyeOffIcon');
    const isHidden = input.type === 'password';

    input.type = isHidden ? 'text' : 'password';
    eyeOn.classList.toggle('hidden', isHidden);
    eyeOff.classList.toggle('hidden', !isHidden);
}
</script>
</html>
<?php /**PATH D:\Project\1017website 2026\tokaku\resources\views/auth/login.blade.php ENDPATH**/ ?>