@extends('layouts.app')
@section('title','Laporan')
@section('page-title','Laporan Penjualan')
@section('page-subtitle','Rekap transaksi dan omzet toko')

@section('content')
<div style="background:#fff;border-radius:16px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);padding:18px 20px;margin-bottom:16px;">
    <form method="GET" class="flex flex-wrap items-end gap-3">
        <div>
            <label style="display:block;font-size:12px;font-weight:500;color:#64748b;margin-bottom:5px;">Dari</label>
            <input type="date" name="start_date" value="{{ $startDate }}" class="form-input" style="width:auto;">
        </div>
        <div>
            <label style="display:block;font-size:12px;font-weight:500;color:#64748b;margin-bottom:5px;">Sampai</label>
            <input type="date" name="end_date" value="{{ $endDate }}" class="form-input" style="width:auto;">
        </div>
        <button type="submit" class="btn-primary">Tampilkan</button>
    </form>
</div>

<div style="background:#0F6E56;border-radius:16px;padding:20px 24px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div>
        <p style="color:rgba(255,255,255,0.7);font-size:13px;font-weight:500;">Total Omzet Periode Ini</p>
        <p style="color:#fff;font-size:26px;font-weight:700;letter-spacing:-0.5px;margin-top:4px;">Rp {{ number_format($totalRevenue,0,',','.') }}</p>
        <p style="color:rgba(255,255,255,0.6);font-size:12px;margin-top:4px;">{{ $transactions->total() }} transaksi</p>
    </div>
    <a href="{{ route('tenant.laporan.export') }}?start_date={{ $startDate }}&end_date={{ $endDate }}"
        style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.15);color:#fff;font-size:13.5px;font-weight:500;padding:10px 18px;border-radius:10px;text-decoration:none;transition:all 0.15s;backdrop-filter:blur(4px);"
        onmouseover="this.style.background='rgba(255,255,255,0.25)'" onmouseout="this.style.background='rgba(255,255,255,0.15)'">
        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
        Export Excel
    </a>
</div>

<div style="background:#fff;border-radius:16px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);overflow:hidden;">
    <div class="overflow-x-auto">
        <table style="width:100%;border-collapse:collapse;min-width:500px;">
            <thead>
                <tr style="background:#f8fafc;border-bottom:1px solid #f1f5f9;">
                    @foreach(['Invoice','Kasir','Metode','Total','Waktu'] as $h)
                    <th style="text-align:{{ in_array($h,['Total'])? 'right':'left' }};font-size:11.5px;font-weight:600;color:#64748b;padding:11px 18px;letter-spacing:0.3px;text-transform:uppercase;">{{ $h }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                @forelse($transactions as $t)
                <tr style="border-bottom:1px solid #f8fafc;transition:background 0.1s;" onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='#fff'">
                    <td style="padding:13px 18px;font-size:13.5px;font-weight:500;color:#0f172a;">{{ $t->invoice_no }}</td>
                    <td style="padding:13px 18px;font-size:13.5px;color:#374151;">{{ $t->user->name }}</td>
                    <td style="padding:13px 18px;">
                        <span style="font-size:12px;font-weight:500;padding:3px 10px;border-radius:99px;{{ $t->payment_method==='cash'?'background:#f0fdf4;color:#15803d;':($t->payment_method==='qris'?'background:#eff6ff;color:#1d4ed8;':'background:#f5f3ff;color:#6d28d9;') }}">
                            {{ strtoupper($t->payment_method) }}
                        </span>
                    </td>
                    <td style="padding:13px 18px;text-align:right;font-size:13.5px;font-weight:700;color:#0f172a;">Rp {{ number_format($t->total,0,',','.') }}</td>
                    <td style="padding:13px 18px;font-size:13px;color:#64748b;">{{ $t->created_at->format('d M Y, H:i') }}</td>
                </tr>
                @empty
                <tr><td colspan="5" style="padding:60px 20px;text-align:center;font-size:14px;color:#94a3b8;">Tidak ada transaksi di periode ini.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($transactions->hasPages())
    <div style="padding:14px 18px;border-top:1px solid #f8fafc;">{{ $transactions->links() }}</div>
    @endif
</div>
@endsection
